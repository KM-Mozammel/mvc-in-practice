<?php
class Controller {

    function runAction($action){

        if(method_exists($this, 'runBeforeAction')){
            $this->runBeforeAction();
        }
    
        if(method_exists($this, $action)){
            $this->$action();
        } else{
            include 'view/status-pages/404.html';
        }
    }

}