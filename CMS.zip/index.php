<?php
    session_start();

    require_once 'src/controller.php';

    $section = $_POST['section'] ?? $_GET['section'] ?? 'default';
    $action = $_POST['action'] ?? $_GET['action'] ?? 'default';

    if($section == 'about'){

        include 'controller/aboutUsPage.php';
        $aboutController = new aboutUsController();
        $aboutController->runAction($section);

    } else if($section == 'contact'){
        
        include 'controller/contactPage.php';
        $contactController = new contactusController();
        $contactController->runAction($action);

    } else{

        include 'controller/homepage.php';
        $homepage = new HomePageController();
        $homepage->runAction($section);
        
    }
?>