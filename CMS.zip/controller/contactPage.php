<?php

    class contactUsController extends Controller{

        function runBeforeAction(){

            if(isset($_SESSION['has_submitted_the_form'])){

                include 'view/contact/contact-us-already-contacted.html';
                exit();
            }

        }

        function default(){

            include 'view/contact/contact-us.html';

        }

        function submit(){

            // Validate
            // Store Data
            // Send email

            $_SESSION['has_submitted_the_form'] = 1;

            include 'view/contact/contact-us-thank-you.html';

        }
        
    }