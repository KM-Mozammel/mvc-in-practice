<?php

    class aboutUsController extends Controller{

        function about(){
            include 'view/about-us.html';
        }
        
    }