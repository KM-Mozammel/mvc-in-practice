<?php

    class homepageController extends Controller {

        function default(){
            include 'view/home-page.html';
        }
        
    }